# NeoGuard revision A — verification record

Date: **20 October 2026**. Native tools: **KiCad 10.0.4**. This record describes checks actually performed on the generated files; it does not establish assembled-hardware operation or manufacturing approval.

## Schematic — checked

- `NeoGuard.kicad_sch` was read/exported by native KiCad. The current PDF is `output/pdf/NeoGuard-schematic.pdf`.
- `ERC.json` reports **0 violations** with error and warning severities included. The report retains its own `ignored_checks` metadata; no resulting errors or warnings were concealed in this record.
- Independent comparison of native `NeoGuard.net.xml` against `design_manifest.json` found **0 pin/net mismatches** across all **31 intended electrical nets**.
- There are **26 electrical components**, **99 symbol pins**, **98 connected pins** and **1 intentional no-connect: J2 pin 5**, reserved for the unused MAX30102 interrupt connection.
- Firmware correspondence was reviewed against `akena firmware/akena_firmware/akena_firmware.ino`: shared I2C GPIO4/5; RTC CLK6/DAT7/CE14; TFT RST8/DC9/CS10/MOSI11/SCK12; SD CS21/SCK40/MOSI41/MISO42; buzzer15; RGB16/17/18.
- Buzzer connectivity was checked: GPIO15 through R6 to Q1 base; R7 base to GND; emitter pad 1 to GND, base pad 2, collector pad 3 to switched buzzer negative; D1 cathode/band pad 1 to positive buzzer supply. The required device is the specified E1/B2/C3 PN2222A, not an arbitrary similarly named transistor.
- Optional I2C pull-ups and the backlight feed are marked DNP. Source/voltage selectors remain distinct nets; shunts are physical assembly choices and must be set correctly.
- The exported schematic preview was visually reviewed for overall layout, GPIO labels, power assumptions and default ST7789 identification. Native-vector PDF zoom is available for the connector labels.
- `BOM.csv` covers each manifest component with its specified footprint. `Wiring.csv` has **72 connector/selector pin rows**, including the intentional no-connect; its net assignments match the manifest.

## PCB — checked

- The final `NeoGuard.kicad_pcb` was independently loaded through native KiCad 10.0.4. All **99 electrical component pads** are present and match the manifest; there are **0 missing pads and 0 net-assignment mismatches**.
- J2 pin 5 has KiCad's isolated `unconnected-(J2-Pin_5-Pad5)` net name and **no attached copper tracks or vias**. This is the intentional MAX interrupt no-connect, not an incomplete route.
- The board contains **30 footprints: 26 electrical components and 4 unplated mounting-hole footprints**. Current dimensions are **140 x 105 mm**, with two copper layers, 1.6 mm board thickness and four 3.2 mm M3 mounting holes.
- Final `pcb_drc.json` from KiCad 10.0.4 reports **0 violations**, **0 unconnected items** and **0 schematic-parity issues**, with both error and warning severities included. Native pin mapping was checked again against the final board after this report.
- Project design rules were read back: **0.25 mm minimum/class copper clearance**, **0.30 mm minimum track width**, **0.50 mm copper-to-edge clearance**, **0.15 mm silkscreen clearance**, and default **0.80 mm via diameter / 0.40 mm drill**. Routed power traces use the recorded 0.60 mm design width. These settings are design constraints, not a manufacturer-specific DFM approval.
- The report lists these ignored check categories in its own metadata: `missing_courtyard`, `track_not_centered_on_via`, `tuning_profile_track_geometries`, `footprint_filters_mismatch`, and `footprint_type_mismatch`. The zero count above describes the checks enabled in that report; it is not a claim that every possible KiCad check was enabled.
- No manufacturing-ready status is asserted. The native project, schematic/PCB and viewing outputs are the handoff; no fabrication files are promised by this validation record.

## Physical checks — not performed

No board has been fabricated, assembled, powered or flashed as part of this design task. The following remain unverified:

- Actual ESP32-S3 development-board physical header layout. J1 is a functional cable connector, not a devboard socket.
- Module connector order, actual breakout power/logic compatibility, backlight requirements and purchased-part dimensions/pinouts.
- Regulator/supply current budget, loaded-rail stability, harness voltage drop, reverse-polarity handling and simultaneous-power behaviour.
- Buzzer load current, Q1 saturation, actual LED polarity/lead order, RTC battery condition and disabled charging.
- Mechanical/enclosure fit, module mounting, assembly tolerances and a manufacturer-specific DFM review.
- Sensor accuracy, integrated display operation, firmware timing, SD logging and end-to-end authenticated backend transfer.

The prior isolated ST7789 display test was recorded as working in the existing project documentation. The blank integrated-screen issue remains an unconfirmed integration fault; the carrier design is not evidence that it is resolved. This prototype includes no medical isolation, patient-protection circuit or clinical validation.
