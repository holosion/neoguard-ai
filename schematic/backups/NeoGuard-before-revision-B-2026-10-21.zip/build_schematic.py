"""Create the editable KiCad carrier schematic from the reviewed wiring manifest."""
from pathlib import Path
import json, re, math, uuid, copy

ROOT = Path(__file__).resolve().parent
LIBROOT = Path(r'C:\Program Files\KiCad\10.0\share\kicad\symbols')
MANIFEST = json.loads((ROOT / 'design_manifest.json').read_text())
NS = uuid.UUID('d620ef9a-1167-4b36-a1d1-cfb663e4d101')
def uid(name): return str(uuid.uuid5(NS, name))
ROOTID = uid('schematic-root')
class Atom(str): pass
def parse(src):
    toks = re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+', src)
    i = 0
    def one():
        nonlocal i
        t=toks[i]; i+=1
        if t=='(':
            out=[]
            while toks[i]!=')': out.append(one())
            i+=1; return out
        if t.startswith('"'): return json.loads(t)
        return Atom(t)
    return one()
def dump(v):
    if isinstance(v, list): return '('+' '.join(dump(x) for x in v)+')'
    if isinstance(v, Atom): return str(v)
    return json.dumps(v, ensure_ascii=False)
def child(v,k): return next((x for x in v[1:] if isinstance(x,list) and x[0]==k),None)
def children(v,k): return [x for x in v[1:] if isinstance(x,list) and x[0]==k]
def rename_nested(v,old,new):
    if isinstance(v,list):
        if len(v)>1 and v[0]=='symbol' and isinstance(v[1],str) and v[1].startswith(old+'_'): v[1]=new+v[1][len(old):]
        for x in v: rename_nested(x,old,new)
cache={}
def libsym(lib,name):
    if lib not in cache:
        t=parse((LIBROOT/(lib+'.kicad_sym')).read_text(encoding='utf-8'))
        cache[lib]={str(x[1]):x for x in children(t,'symbol')}
    sym=copy.deepcopy(cache[lib][name]); ext=child(sym,'extends')
    if ext:
        base=libsym(lib,str(ext[1])); old=str(base[1]); rename_nested(base,old,name); base[1]=name
        props={str(p[1]):p for p in children(base,'property')}
        for p in children(sym,'property'): props[str(p[1])]=p
        base=[x for x in base if not (isinstance(x,list) and x[0]=='property')]
        base.extend(props.values()); sym=base
    return sym

LIBS={}
for c in MANIFEST['components']:
    lib,name=c['symbol'].split(':')
    if name not in LIBS: LIBS[name]=libsym(lib,name)

def effects(size=1,justify='left',hide=False):
    j=f'(justify {justify})' if justify else ''
    return f'(effects (font (size {size} {size})) {j} '+('hide' if hide else '')+')'
items=[]; counter=0; placed={}; pinpoints={}
def add(s): items.append(s)
def text(s,x,y,size=1.05,bold=False):
    add(f'(text {json.dumps(s)} (at {x} {y} 0) (effects (font (size {size} {size}) '+('bold' if bold else '')+f') (justify left top)) (uuid {uid("text-"+str(len(items)))}))')
def wire(a,b):
    if a==b:return
    add(f'(wire (pts (xy {a[0]} {a[1]}) (xy {b[0]} {b[1]})) (stroke (width 0) (type default)) (uuid {uid("wire-"+str(len(items)))}))')
def label(net,p,angle=0):
    add(f'(label {json.dumps(net)} (at {p[0]} {p[1]} {angle}) {effects(0.95,"left bottom")} (uuid {uid("label-"+str(len(items)))}))')
def junction(p): add(f'(junction (at {p[0]} {p[1]}) (diameter 0) (color 0 0 0 0) (uuid {uid("junction-"+str(len(items)))}))')
def pin_defs(sym):
    out=[]
    for sub in children(sym,'symbol'):
        for p in children(sub,'pin'):
            at=child(p,'at'); num=child(p,'number')
            out.append((str(num[1]),float(at[1]),float(at[2]),float(at[3])))
    return out
def pospin(x,y,angle,px,py):
    a=math.radians(angle)
    return round(x+px*math.cos(a)-py*math.sin(a),4),round(y-px*math.sin(a)-py*math.cos(a),4)
def place(ref,x,y,angle=0,labels=True,showval=False):
    c=next(c for c in MANIFEST['components'] if c['ref']==ref); name=c['symbol'].split(':')[1]; sym=LIBS[name]
    sid=uid('instance-'+ref); placed[ref]=sid
    refy=y-8 if ref[0]=='J' else y-5
    valy=refy-2; refx=valx=x
    if angle in (90,270): refx=x-5;valx=x+5;refy=valy=y-3.5
    props=f'(property "Reference" "{ref}" (at {refx} {refy} {angle}) {effects(1.15,"")})'
    props+=f'(property "Value" {json.dumps(c["value"])} (at {valx} {valy} {angle}) {effects(1, "", not showval)})'
    props+=f'(property "Footprint" {json.dumps(c["footprint"])} (at {x} {y} 0) {effects(1,"",True)})'
    pins=''
    for n,px,py,pa in pin_defs(sym):
        p=pospin(x,y,angle,px,py); pinpoints[(ref,n)]=p
        pins+=f'(pin {json.dumps(n)} (uuid {uid(ref+"-pin-"+n)}))'
        net=c['pins'][n]
        if net is None:
            add(f'(no_connect (at {p[0]} {p[1]}) (uuid {uid(ref+"-nc-"+n)}))');continue
        if labels:
            # Pins point INTO the body. Their outward wire is opposite that direction.
            a=math.radians(angle+pa)
            p2=(round(p[0]-7.62*math.cos(a),4),round(p[1]+7.62*math.sin(a),4))
            wire(p,p2)
            if abs(math.sin(a))<0.1:
                label(net,p2,0 if math.cos(a)<0 else 0)
                # Put left-facing labels against the body, preserving readable orientation.
                if math.cos(a)>0:
                    items[-1]=items[-1].replace('(justify left bottom)','(justify right bottom)')
            else: label(net,p2,0)
    add(f'(symbol (lib_id "NeoGuard:{name}") (at {x} {y} {angle}) (unit 1) (in_bom yes) (on_board yes) (dnp {"yes" if c.get("dnp") else "no"}) (uuid {sid}) {props} {pins} (instances (project "NeoGuard" (path "/{ROOTID}" (reference "{ref}") (unit 1)))))')
def pinlabel(ref,n,net=None,delta=(0,5.08),right=False):
    p=pinpoints[(ref,str(n))]; q=(round(p[0]+delta[0],4),round(p[1]+delta[1],4));wire(p,q)
    c=next(c for c in MANIFEST['components'] if c['ref']==ref)
    label(net or c['pins'][str(n)],q)

text('NEOGUARD | COMPLETE MODULE CARRIER',15,14,2.5,True)
text('ESP32-S3 + MAX30102 + MLX90614 + DS1302 + ST7789 + microSD + local alarms',15,21,1.35)
text('Revision A - functional cable pin order; NOT a direct devboard/module socket. All signal levels 3.3 V.',15,27,1.05)
text('CONTROLLER HARNESS',20,39,1.5,True)
place('J1',78.74,68.58)
text('J1: wire to the GPIO LABELS on the ESP32-S3.\nPin 2 = devboard 3V3 OUT; extra GND returns at 21-24.\nNative USB stays on the existing devboard.\nKeep SPI leads short. No old parallel LCD.',20,111,1.05)
text('Built-in Wi-Fi -> HTTPS backend -> clinical dashboard.\nNo extra Wi-Fi module or network GPIO is required.',20,130,1)
text('MAX30102 / 0x57',145,39,1.4,True)
place('J2',195.58,55.88)
text('1 VCC; 2 GND; 3 SDA; 4 SCL; 5 INT unused.\nOnly a 3.3 V supply/logic compatible breakout.',145,75,1)
text('MLX90614 / 0x5A',240,39,1.4,True)
place('J3',289.56,55.88)
text('3.3 V breakout required. Surface/object temperature.\n5 V variants need a separate reviewed interface.',240,75,1)
text('DS1302 RTC',335,39,1.4,True)
place('J4',386.08,55.88)
text('3-wire: CLK6 / DAT7 / CE14; not I2C.\nBattery stays on module. Disable CR2032 charging.',335,75,1)
text('ST7789 TFT / 240 x 280',145,90,1.4,True)
place('J5',213.36,106.68)
text('The working display-test driver is ST7789, not SSD1306.\nMOSI11 / SCK12 / CS10 / DC9 / RST8.\nJP4 backlight link remains OPEN until module verified.',145,130,1)
text('MICROSD / INDEPENDENT SPI',275,90,1.4,True)
place('J6',345.44,106.68)
text('SD power selected by JP2. Never feed 5 V to a bare card.\nUse only a breakout with 3.3 V compatible I/O.\nCS21 / SCK40 / MOSI41 / MISO42.',275,130,1)

text('REGULATED POWER INPUTS / SELECTORS',20,149,1.5,True)
place('J9',63.5,165.1)
text('J9: regulated supplies ONLY.\n1 = external 3V3; 2 = GND; 3 = optional 5V.\nNo regulator or reverse-polarity protection here.',20,179,1)
place('JP1',139.7,165.1)
text('JP1 / 3V3 SOURCE\n1-2 = devboard; 2-3 = external 3V3.\nONE SHUNT ONLY. Never tie both sources.',97,179,1)
place('JP2',228.6,165.1)
text('JP2 / SD SUPPLY\n1-2 = 3V3; 2-3 = external 5V.\nONE SHUNT ONLY; match module rating.',184,179,1)
place('JP3',317.5,165.1)
text('JP3 / BUZZER SUPPLY\n1-2 = 3V3; 2-3 = external 5V.\nONE SHUNT ONLY; match buzzer rating.',273,179,1)
place('JP4',391.16,165.1)
text('JP4 / TFT BL\nOpen by default. Fit only for a\nverified 3V3-compatible BL input.',350,179,1)

text('BYPASS / OPTIONAL I2C PULL-UPS',20,201,1.3,True)
place('C1',35.56,215.9,showval=True)
place('C2',68.58,215.9,showval=True)
place('C3',101.6,215.9,showval=True)
place('C4',134.62,215.9,showval=True)
place('R1',35.56,241.3,showval=True)
place('R2',101.6,241.3,showval=True)
text('R1/R2 DNP if breakout pull-ups already fitted.\nPull-ups must go to V3V3, never 5 V.',20,257,1)

text('RGB - COMMON CATHODE',184,201,1.3,True)
for ref,y,inp,out in [('R3',215.9,'LED_R_GPIO16','LED_R_A'),('R4',228.6,'LED_G_GPIO17','LED_G_A'),('R5',241.3,'LED_B_GPIO18','LED_B_A')]:
    place(ref,228.6,y,90,labels=False,showval=True)
    pinlabel(ref,1,delta=(-15.24,0));pinlabel(ref,2,delta=(12.7,0))
place('J7',284.48,228.6)
text('One 330R resistor per colour.\nExternal LED pin order must be checked.',184,257,1)

text('BUZZER DRIVER - ACTIVE HIGH',310,201,1.3,True)
place('R6',330.2,226.06,90,labels=False,showval=True)
place('Q1',355.6,226.06,labels=False)
text('Q1 PN2222A\nE=1 B=2 C=3',363,234,1)
place('R7',342.9,241.3,labels=False,showval=True)
place('D1',378.46,218.44,270,labels=False)
text('D1 1N5819\nK/stripe to BUZZ_VCC',368,207,0.95)
place('J8',398.78,226.06,labels=False)
text('J8: +1 / -2. Buzzer: 20 mA maximum.',310,249,1)
# Explicit base drive / pulldown, emitter return and flyback wiring.
pinlabel('R6',1,delta=(-10.16,0))
base_node=(342.9,226.06)
wire(pinpoints[('R6','2')],base_node);wire(base_node,pinpoints[('Q1','2')]);junction(base_node)
base_label=(342.9,218.44)
wire(base_node,base_label);label('BUZZ_BASE',base_label)
wire(base_node,pinpoints[('R7','1')])
pinlabel('R7',2,delta=(0,5.08))
pinlabel('Q1',1,delta=(0,20.32))
collector=pinpoints[('Q1','3')]
collect_node=(collector[0],218.44)
wire(collector,collect_node);label('BUZZ_SW',collect_node)
for ref,n in [('D1','1'),('D1','2'),('J8','1'),('J8','2')]:
    pinlabel(ref,n,delta=(0,-2.54) if (ref,n)==('D1','1') else (0,2.54) if ref=='D1' else (-5.08,0))

text('ASSEMBLY: selector pins must be verified before power. Power controller/peripherals together; no signal isolation is provided.',15,272,1)
text('Prototype carrier only. Module connector pin order is the carrier definition, not a claim about module header order. No PCB-mounted bare sensors or radio.',15,277,1)

# Set stable references and a local self-contained symbol library.
symdefs=[]
for name,s in LIBS.items():
    st=copy.deepcopy(s);st[1]='NeoGuard:'+name;symdefs.append(dump(st))
title='(title_block (title "NeoGuard - Complete Module Carrier") (date "2026-10-20") (rev "A") (company "Neonatal research prototype") (comment 1 "Functional harness; verify module voltages and pin order before assembly"))'
schematic=f'(kicad_sch (version 20250114) (generator "neoguard_design") (uuid {ROOTID}) (paper "A3") {title} (lib_symbols '+''.join(symdefs)+')\n'+'\n'.join(items)+f'\n(sheet_instances (path "/" (page "1"))) (embedded_fonts no))\n'
(ROOT/'NeoGuard.kicad_sch').write_text(schematic,encoding='utf-8')
library='(kicad_symbol_lib (version 20251024) (generator "neoguard_design")\n'+'\n'.join(dump(s) for s in LIBS.values())+'\n)\n'
(ROOT/'NeoGuard.kicad_sym').write_text(library,encoding='utf-8')
(ROOT/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "NeoGuard") (type "KiCad") (uri "${KIPRJMOD}/NeoGuard.kicad_sym") (options "") (descr "Self-contained carrier schematic symbols")))\n')
fpnames=sorted({c['footprint'].split(':')[0] for c in MANIFEST['components']})
(ROOT/'fp-lib-table').write_text('(fp_lib_table (version 7) '+' '.join(f'(lib (name "{n}") (type "KiCad") (uri "${{KICAD10_FOOTPRINT_DIR}}/{n}.pretty") (options "") (descr "KiCad stock library"))' for n in fpnames)+')\n')
project={"meta":{"filename":"NeoGuard.kicad_pro","version":1},"board":{"design_settings":{"rules":{"min_clearance":0.25,"min_track_width":0.3,"min_via_diameter":0.8,"min_through_hole_diameter":0.3},"drc_exclusions":[]}},"net_settings":{"classes":[{"name":"Default","description":"Carrier signals","clearance":0.25,"track_width":0.3,"via_diameter":0.8,"via_drill":0.4,"microvia_diameter":0.3,"microvia_drill":0.1,"diff_pair_width":0.3,"diff_pair_gap":0.25,"diff_pair_via_gap":0.25}],"meta":{"version":3}},"text_variables":{},"schematic":{}}
if not (ROOT/'NeoGuard.kicad_pro').exists(): (ROOT/'NeoGuard.kicad_pro').write_text(json.dumps(project,indent=2))
(ROOT/'schematic_ids.json').write_text(json.dumps({'root_uuid':ROOTID,'symbols':placed},indent=2))
print(f'Wrote schematic: {len(placed)} components, {len(items)} objects, {len(pinpoints)} pins.')
