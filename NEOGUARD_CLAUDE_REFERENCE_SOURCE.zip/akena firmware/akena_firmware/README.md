# Akena NeoGuard: minute-long signal check, alarms and phone Wi-Fi setup

Open **akena_firmware.ino** and keep every sibling `.h` file with it. This revision starts from the latest working `Desktop/sketch_oct12a` code. The display controller, icons and pin assignments are preserved. It is an experimental bench prototype, not a validated neonatal monitor. MLX90614 measures surface/object temperature, not core body temperature.

## Upload

Use your existing ESP32-S3 board, flash and PSRAM settings. Enable **USB CDC On Boot** for native USB serial. Install/keep these Arduino libraries: **SparkFun MAX3010x Pulse and Proximity Sensor Library**, **Adafruit MLX90614 Library**, **Rtc by Makuna**, **Adafruit GFX Library**, **Adafruit ST7735 and ST7789 Library**, **ArduinoJson 7**, and **WiFiManager by tzapu 2.0.17**. ESP32 supplies SD, SPI, Wire, Wi-Fi and Preferences. The default display is the working ST7789 240x280; SSD1306 mode additionally needs its existing library.

Upload the complete sketch folder. No images or configuration JSON files need copying to the SD card. HTTPS trust is embedded in `root_ca.h`. Do not flash the earlier oximeter-only test for this version.

## Phone Wi-Fi setup, like Lumora

1. Power the device. The D3 revision first shows a white **NEOGUARD D3 / 1. SCREEN-ONLY START** page for two seconds, using the successful screen test sequence before starting LEDs, I2C or the SD SPI bus. Numbered checks then identify startup progress before the Wi-Fi setup page appears. Without saved working Wi-Fi, it opens **NeoGuard-XXXX**. A full setup page shows the network name, unique password and **192.168.4.1** together until setup finishes. This works in both the colour TFT and optional monochrome OLED layout. Serial Monitor at 115200 also prints the setup details. The password is saved in the ESP32 and is not the old Lumora password.
2. Connect your phone to that network. Accept the phone's option to remain connected without internet. Open the sign-in popup, or browse to **http://192.168.4.1**. Select **Configure WiFi**.
3. Choose an available **2.4 GHz** network and enter its password. In the same form, enter the dashboard's registered **device code**, its **device secret**, and the API URL. The default is `https://neoguard-api-wwth.onrender.com/api/v1`. A dashboard login password is not a device secret. A blank device-secret field keeps the saved secret only when the device code stays the same; a different registered device needs its own secret.
4. Save. When Wi-Fi connects and settings have been saved, the device restarts with the new configuration. Saved Wi-Fi reconnects on later boots. The setup access point closes after successful setup. Wrong or unavailable Wi-Fi returns to setup without stopping sensor acquisition.
5. To reconfigure a connected device, send **WIFI SETUP** with a newline in Serial Monitor. If credentials are missing, reboot also reopens setup. Device credentials are stored locally in ESP32 preferences and are not printed to Serial Monitor.

This uses the same WiFiManager library and network-selection flow as Lumora, with setup running separately from the sensor task. Library reference: https://github.com/tzapu/WiFiManager . Only use a backend whose HTTPS certificate chains to the embedded trusted root, or update the root for the intended service. NTP or a correctly set RTC is needed for certificate time checks.

The same previously working screen remains selected (`DISPLAY_KIND 1`); do not change this just because it is called an OLED. The TFT transfer speed is now 1 MHz, matching the screen-only test that the user confirmed displays text and an increasing count. That result verifies the screen in isolation; it does not yet verify the full firmware with SD, Wi-Fi and sensors running. During phone setup, alarms and sensor sampling continue; an alarm/sensor status appears beneath the connection instructions. After setup, the normal readings return and the screen also shows the connected Wi-Fi IP address. If even the startup message stays blank after uploading this revision, check the existing display power, common ground and display connections with power off: MOSI 11, SCK 12, CS 10, DC 9, RST 8. Keep the module's previously working supply voltage.

## Dashboard assignment and real data

In the existing dashboard, an administrator registers the device in the correct clinic and saves the one-time device secret. Activate that device. An administrator or clinician creates/selects the intended patient and starts a monitoring session on the device. View live readings with a **nurse/clinician** account; the administrator registry view intentionally does not expose clinical readings.

For the default cloud API, use the cloud dashboard at **https://neoguard-ai-lovat.vercel.app** for registration and assignment. A device secret issued by a different local database will not authenticate against that cloud API. Keep the dashboard, device credential and firmware API URL on the same backend.

The firmware discovers the assigned session automatically every ten seconds. There is no manually entered session ID in the phone form. Without an assigned session it still measures, alarms and writes the CSV, but does not attach measurements to a patient. Starting/changing a session resets the minute-long signal check so previous-patient samples are not reused. Do not move the device to another patient while offline: reconnect, stop the old session, assign the new patient and allow the firmware to discover that assignment before collecting for them.

New backend code provides authenticated **GET /api/v1/devices/runtime** for the assigned session, active thresholds and server time. The firmware can fall back to the existing **/devices/current-session** on an older deployment; the TFT then says **LOCAL LIMITS / ONLINE**, indicating cached/project-default limits rather than freshly downloaded settings. New server-time synchronization adjusts the DS1302 to Nairobi time. A clock can also be set using the supplied `sync_rtc.ps1` or the existing serial TIME command.

Once the signal qualifies, the firmware records a new upload event every five seconds and offers batches approximately every six seconds. It uses authenticated **POST /api/v1/devices/sync**, which the existing backend already supports. Heartbeats update connectivity during the measurement countdown without inventing patient readings. The local frontend refresh interval is now five seconds, overlapping refresh requests are prevented, and the local empty-preview mode is disabled. Existing cloud releases retain their previous behavior until those source changes are deployed; no cloud deployment or device registration is performed by writing this sketch.

## The minute-long measurement

- Keep an adult finger gently and continuously on the MAX30102 optical window for a bench test. Keep the temperature sensor steadily aimed at the intended surface; holding the finger on the pulse sensor does not position the temperature sensor.
- The TFT shows **HOLD FINGER N/60s** and withholds the large HR, oxygen and surface-temperature numbers until the signal qualifies. No random, simulated, clamped or fabricated values are substituted.
- There must be at least 45 valid one-second observations in the last minute, including at least 12 valid observations among the last 15. The recent spread must be no more than 12 bpm, 3 SpO2 percentage points and 0.4°C. These are provisional repeatability gates, not clinical accuracy criteria.
- Qualified values are medians of the latest valid 15-second tail and update every five seconds. They continue following real changes. Finger removal, stale samples or an unstable signal clears the displayed result; it does not freeze the last number indefinitely. **SIGNAL UNSTABLE** means keep still and check sensor placement, supply, contact and motion. Waiting a minute alone cannot guarantee an accurate or clinically valid result.
- Pulse acquisition runs in a separate task every five milliseconds and shares the I2C bus with temperature/OLED access through a mutex. SD writes, display drawing and HTTPS requests no longer own the pulse-collection loop. Sampling gaps still invalidate measurements; this is not a guaranteed real-time acquisition system.

## Red LED and buzzer thresholds

The user selected the existing project limits. Defaults, also used before a server configuration is available, are:

| Parameter | Alarm condition |
| --- | --- |
| Heart rate | Below 100 or above 160 bpm |
| Surface temperature | Below 36.5°C |
| SpO2 | Below 90% |

There is **no upper-temperature alarm threshold** in the existing project, and no new upper limit has been invented. The dashboard's existing moderate/severe low-temperature categories remain unchanged. New firmware downloads the currently configured limits from the new authenticated runtime endpoint and caches them for offline use.

Three consecutive valid one-second threshold breaches trigger **red plus a repeating 250 ms buzzer pulse**. Raw valid measurements are evaluated during the countdown, so an alarm does not wait for the full minute. A displayed stabilized result outside a limit also keeps the alarm active. Three consecutive fully valid in-range observations clear the raw alarm; invalid readings cannot be treated as recovery. Finger removal clears the measurement/contact alarm and shows placement instructions.

Blue means running/acquiring with no currently detected threshold alarm. A missing/failed sensor also shows red, with a shorter beep every two seconds. The startup test beep remains. Clock, network and SD problems have separate visible status. Blue is not a statement that a baby is healthy. The existing transistor-driven buzzer wiring and active-high settings are preserved; an incorrectly wired or different buzzer module cannot be corrected in software alone.

## SD recording and replay

Use the existing FAT32 card and independent SPI bus: **CS21, SCK40, MOSI41, MISO42**, shared ground. Supply the SD module at its actual rated voltage. A regulator-equipped module may need 5 V at its supply input; a native 3.3 V breakout needs 3.3 V. ESP32 signals remain 3.3 V logic. The breadboard supply ground, ESP32 ground and all module grounds must join. Verify rail voltage at the module and check split breadboard rails. Do not tie an external regulated positive rail to USB-powered ESP32 power outputs.

**/neoguard_v2.csv** appends approximately every second. It contains stabilized readings when available, raw HR/SpO2/object-temperature values, validity/contact flags, measurement elapsed time and alarm flags. Earlier `/neoguard.csv` files are preserved. Startup tries 1 MHz and 400 kHz SD speeds, checks the header after opening, and retries unavailable storage at ten-second intervals while no finger is present. Remove the finger to let failed storage retry; this keeps slow mount attempts out of the minute-long measurement. It never formats or erases a card.

**/pending.ndjson** stores eligible upload events with immutable UUIDs, observation times and original session IDs. The backend input ranges remain HR 40–220, SpO2 50–100 and temperature 30–42°C. Out-of-range fields stay in the CSV and are omitted from upload; they are never clamped. Partial records have quality `poor`, as in the previous firmware. A full quality `ok` record needs all eligible stabilized fields. The existing backend treats poor-quality records separately from clinical threshold evaluation.

**/sync.cursor** advances only after every event in a batch is acknowledged as `accepted` or `duplicate` and the checkpoint is written. Lost connections and timeouts retain the batch. Duplicates reuse the saved UUID, so replay does not create extra readings. A rejected SD batch is retained for inspection and blocks later SD batches until its session/clock/configuration problem is resolved. Corrupt queue files also remain untouched; new live events can use RAM while a corrupt queue needs attention. No records are silently assigned to a new patient or erased to bypass an error.

Without working SD, up to **12 upload events** are kept temporarily in RAM and can still be delivered online. They do not survive power loss; after that queue fills, a serial counter reports readings that could not be retained. Successful SD logging is therefore needed for durable offline operation. Preserve queue/cursor files together, manage card/file capacity, and power down before inserting/removing or changing cards. Use a card for only its intended device; old events sent with a different device's credentials will be rejected by the backend.

Cached assignment can survive a reboot offline. This retains the original session identity but cannot know that someone changed patients while disconnected; the backend verifies original session time bounds and rejects mismatches. Configure the device and establish its session/clock online **before** offline collection. CSV data collected while unassigned or with an unset clock is not retrospectively attached to a patient.

## Bench check after upload

1. Confirm the phone portal, saved Wi-Fi reconnect, and **NO ACTIVE SESSION** before dashboard assignment. Register/activate/assign the device and confirm the status changes automatically.
2. Hold still for at least one minute. Confirm the countdown, withheld values before qualification, and real values only after a stable signal. Move/remove the finger and verify values clear rather than remain frozen.
3. Check threshold behavior using controlled bench inputs or the tested logic, not a patient: red/buzzer on a confirmed breach, blue after recovery. Confirm the displayed limit matches the server when the runtime endpoint is deployed. An adult's normal pulse can be below the project's neonatal prototype threshold and trigger an alarm.
4. Confirm a nurse/clinician dashboard shows incoming real readings. Disconnect Wi-Fi for a minute with SD logging active, reboot if desired, reconnect and confirm historical readings return to the same session without duplicates.
5. Power down and inspect the CSV/queue/cursor files. Check raw versus median values and actual observation times. Record any SD errors or missing records; do not assume zero loss from the display row count.

Compilation and automated tests cannot establish assembled sensor accuracy, actual SD writes, buzzer sound, phone captive-portal behavior or an authenticated ESP32-to-cloud transfer. See BUILD_CHECK.txt for the checks performed on the software.



## D3 blank-screen diagnosis

The screen-only test was confirmed working, but the integrated version at 1 MHz remained blank. D3 changes startup order so the display begins before the LEDs, I2C and SD bus. It shows white progress pages 1 through 8 and prints each step at 115200 in Serial Monitor. The last visible step, together with the serial output after RESET, identifies where to investigate. This change does not establish the root cause or confirm the integrated display works. If the screen remains blank throughout, copy the Serial Monitor output beginning with NEOGUARD FULL FIRMWARE D3 so we can first verify which firmware is running. No wiring changes are required for this check.

